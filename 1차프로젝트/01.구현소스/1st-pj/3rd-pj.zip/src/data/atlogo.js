export const ATLogo = [
	{
		plname: "player-1",
		plimg: "./image/player/player-1.png",
	},
	{
		plname: "player-2",
		plimg: "./image/player/player-2.png",
	},
	{
		plname: "player-3",
		plimg: "./image/player/player-3.png",
	},
	{
		plname: "player-4",
		plimg: "./image/player/player-4.png",
	},
	{
		plname: "player-5",
		plimg: "./image/player/player-5.png",
	},
	{
		plname: "player-6",
		plimg: "./image/player/player-6.png",
	},
];
