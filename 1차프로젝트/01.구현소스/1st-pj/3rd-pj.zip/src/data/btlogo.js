export const BTLogo = [
	{
		lgname: "tlogo-1",
		lgimg: "./image/logo/tlogo1-B.png",
		plname: "bplayer-1",
		plimg: "./image/player/Bplayer-1.png",
	},
	{
		lgname: "tlogo-2",
		lgimg: "./image/logo/tlogo2-B.png",
		plname: "bplayer-2",
		plimg: "./image/player/Bplayer-2.png",
	},
	{
		lgname: "tlogo-3",
		lgimg: "./image/logo/tlogo3-B.png",
		plname: "bplayer-3",
		plimg: "./image/player/Bplayer-3.png",
	},
	{
		lgname: "tlogo-4",
		lgimg: "./image/logo/tlogo4-B.png",
		plname: "bplayer-4",
		plimg: "./image/player/Bplayer-4.png",
	},
	{
		lgname: "tlogo-5",
		lgimg: "./image/logo/tlogo5-B.png",
		plname: "bplayer-5",
		plimg: "./image/player/Bplayer-5.png",
	},
	{
		lgname: "tlogo-6",
		lgimg: "./image/logo/tlogo6-B.png",
	},
	{
		lgname: "tlogo-7",
		lgimg: "./image/logo/tlogo7-B.png",
	},
	{
		lgname: "tlogo-8",
		lgimg: "./image/logo/tlogo8-B.png",
		
	},
	{
		lgname: "tlogo-9",
		lgimg: "./image/logo/tlogo9-B.png",
	},
	{
		lgname: "tlogo-10",
		lgimg: "./image/logo/tlogo10-B.png",
		
	},
];
