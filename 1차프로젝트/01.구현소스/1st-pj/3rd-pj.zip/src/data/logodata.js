export const LogoData = [
    {
        name: 'netflix',
        img:"./image/logo/Netflix.png",
        src:"https://www.netflix.com/kr/title/81614459"
    },
    {
        name: 'tving',
        img:"./image/logo/TVing.png",
        src:"https://www.tving.com/contents/P001609758"
    },
    {
        name: 'disney',
        img:"./image/logo/disney.png",
        src:"https://www.disneyplus.com/ko-kr/series/a-clean-sweep/7MipMuyGlPHc"
    },
]; 
