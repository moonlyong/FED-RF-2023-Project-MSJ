export const Pinfo = [
	{
		plname: "장원삼",
		plimg: "./image/player/rp1.jpg",
	},
	{
		plname: "박용택",
		plimg: "./image/player/rp2.jpg",
	},
	{
		plname: "정성훈",
		plimg: "./image/player/.jpg",
	},
	{
		plname: "정근우",
		plimg: "./image/player/.jpg",
	},
	{
		plname: "",
		plimg: "./image/player/.jpg",
	},
	{
		plname: "",
		plimg: "./image/player/.jpg",
	},
	{
		plname: "",
		plimg: "./image/player/.jpg",
	},
	{
		plname: "",
		plimg: "./image/player/.jpg",
	},
	{
		plname: "",
		plimg: "./image/player/.jpg",
	},
	{
		plname: "",
		plimg: "./image/player/.jpg",
	},
];
