export const MenuData = [
    {
        name: '프로그램소개',
        src:"/"
    },
    {
        name: '하이라이트',
        src:"/hilite"
    },
    {
        name: '선수단소개',
        src:"/playerinfo"
    },
    {
        name: '기존소스',
        src:"https://moonlyong.github.io/FED-RF-2023-Project-MSJ/1%EC%B0%A8%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8/01.%EA%B5%AC%ED%98%84%EC%86%8C%EC%8A%A4/html/"
    },

]; 