// MainArea 컴포넌트

import { Outlet } from "react-router-dom";


export function MainArea() {

  return (
      <Outlet />
  );
} ///////// MainArea 컴포넌트 ////////////