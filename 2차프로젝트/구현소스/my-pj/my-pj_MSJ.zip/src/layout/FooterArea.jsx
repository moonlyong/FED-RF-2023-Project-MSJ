// Pilot PJ 하단영역 공통 컴포넌트

import { Bottom } from "../pages/bottom";

export function FooterArea(){
    return(
        <>
            <Bottom />
        </>
    );
} //////////////// FooterArea 컴포넌트 //////////