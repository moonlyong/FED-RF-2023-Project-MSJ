// Pilot PJ 상단영역 공통 컴포넌트

import { Top } from "../pages/top";

// GNB 데이터 가져오기
export function TopArea(props) {
    
    return (
        <>
            <Top />
        </>
    );
} //////////////// TopArea 컴포넌트 //////////
