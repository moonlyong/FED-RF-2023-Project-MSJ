import "../css/service.css";
import { Banner } from "../module/Banner";


export function Service(){
    
    return (
        <>
           <div id="middle-area">
            <Banner></Banner>
           </div>
        </>
    )
}