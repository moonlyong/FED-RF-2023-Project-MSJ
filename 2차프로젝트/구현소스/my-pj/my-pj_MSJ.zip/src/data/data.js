export const pickdata = [
    {
        tit: "교통",
        imoz: "🚍",
    },
    {
        tit: "주유",
        imoz: "⛽",
    },
    {
        tit: "통신",
        imoz: "📱",
    },
    {
        tit: "마트",
        imoz: "🛒",
    },
    {
        tit: "쇼핑",
        imoz: "🎁",
    },
    {
        tit: "외식",
        imoz: "🍛",
    },
    {
        tit: "카페",
        imoz: "☕️",
    },
    {
        tit: "의료",
        imoz: "🏥",
    },
    {
        tit: "자동차",
        imoz: "🚘",
    },
    {
        tit: "문화",
        imoz: "🎬",
    },
    {
        tit: "항공",
        imoz: "✈️",
    },
    {
        tit: "해외",
        imoz: "🌎",
    },
    {
        tit: "공과금",
        imoz: "🧾",
    },
    {
        tit: "숙박",
        imoz: "🧳",
    },
    {
        tit: "애완동물",
        imoz: "🐱",
    },
];