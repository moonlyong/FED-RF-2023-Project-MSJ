export const BannerData = [
    {
        src:"./img/banner/sb1.jpg",
        txt:"월 200을 위한 알짜 신용·체크카드 추천"
    },
    {
        src:"./img/banner/sb2.jpg",
        txt:"1 vs 1, 에디터가 깐깐하게 비교한 카드혜택"
    },
    {
        src:"./img/banner/sb3.jpg",
        txt:"NO 카드값 폭탄! 나만 안하고 있던 카드꿀팁"
    },
    {
        src:"./img/banner/sb4.jpg",
        txt:"연말정산 준비할 타이밍! 이대로만 따라오세요"
    },
    {
        src:"./img/banner/sb5.jpg",
        txt:"교통비 인상, 알뜰교통카드로 80만원 할인받기"
    },
    {
        src:"./img/banner/sb6.jpg",
        txt:"출국 D-7, 해외여행 결제카드 준비!"
    }


]