export const TopData = [
    {
        src:"./img/banner/tb1.jpg",
    },
    {
        src:"./img/banner/tb2.jpg",
    },
    {
        src:"./img/banner/tb3.jpg",
    },
   
]